#pragma once

enum class ArmorSlot : int
{
	HELMET,
	CHESTPLATE,
	LEGGINGS,
	BOOTS
};
