#pragma once

class EnchantmentInstance
{
public:
	int type;
	int level;
  char filler[6];
public:
	EnchantmentInstance(int, int);
	EnchantmentInstance();
public:
	void setEnchantType(int);
	void setEnchantLevel(int);
	int getEnchantType() const;
	int getEnchantLevel() const;
};
