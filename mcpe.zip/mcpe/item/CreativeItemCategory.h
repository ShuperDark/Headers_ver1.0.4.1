#pragma once

enum class CreativeItemCategory : unsigned char
{
	BLOCKS = 1,
	DECORATIONS,
	TOOLS,
	ITEMS
};
