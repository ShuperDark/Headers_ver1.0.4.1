#pragma once

#include <string>

#include "Item.h"

class ItemInstance;
class Player;
class BlockID;
class Entity;
class Mob;
class TextureUVCoordinateSet;

class BowItem : public Item {
public:
  int _getLauncherPower(int) const;

  BowItem(std::string const&, int);

  virtual ~BowItem();
  virtual Item* setIcon(std::string const&, int);
  virtual int getEnchantSlot() const;
  virtual int getEnchantValue() const;
  virtual bool use(ItemInstance&, Player&);
  virtual void mineBlock(ItemInstance*, BlockID, int, int, int, Entity*);
  virtual bool releaseUsing(ItemInstance*, Player*, int);
  virtual void hurtEnemy(ItemInstance*, Mob*, Mob*);
  virtual const TextureUVCoordinateSet& getIcon(int, int, bool) const;
};