#pragma once

enum class UseAnimation : unsigned char
{
	NONE,
	EAT,
	DRINK,
	BLOCK,
	BOW,
	CAMERA
};
