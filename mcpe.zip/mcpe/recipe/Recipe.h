#pragma once

class Recipe
{
public:
	static bool isAnyAuxValue(int);
	//static bool isAnyAuxValue(ItemInstance const*);
};
