#pragma once

#include <memory>

class MinecraftClient;
class UIControl;
class ItemInHandRenderer
{
public:
	void render(bool,float);
};
