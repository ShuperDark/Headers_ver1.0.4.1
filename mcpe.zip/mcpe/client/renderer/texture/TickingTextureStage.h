#pragma once

struct RenderGraphContext;
struct TickingTextureStage
{
	void render(RenderGraphContext&);
};
