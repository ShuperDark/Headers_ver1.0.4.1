#pragma once

enum TextureFile
{
	FILE_TERRAIN,
	FILE_ITEM
};