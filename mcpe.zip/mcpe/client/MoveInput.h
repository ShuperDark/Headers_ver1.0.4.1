#pragma once

class MoveInput
{
public:
	void setJumping(bool);
};
