#pragma once

// Size : 16
class IntRectangle
{
public:
	int xLeft;	// 0
	int yTop;	// 4
	int width;	// 8
	int height;	// 12
};
