#pragma once

class Realms
{
public:
	class World
	{
		
	};
};
