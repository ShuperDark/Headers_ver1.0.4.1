#pragma once

#include <string>

class Localization
{
public:
	void _load(std::string const&);
	void _appendTranslations(std::string const&);
};
