#pragma once

enum class EntityCategory : int
{
	
};
