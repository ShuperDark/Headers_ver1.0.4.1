#pragma once

enum class EquipmentSlot:int
{
	
};
