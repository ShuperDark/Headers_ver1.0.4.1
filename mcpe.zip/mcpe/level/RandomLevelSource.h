#pragma once

class LevelChunk;

class RandomLevelSource
{
public:
	void loadChunk(LevelChunk&, bool);
};
