#pragma once

enum class DimensionId : int
{
	OVERWORLD,
	NETHER,
	END
};
