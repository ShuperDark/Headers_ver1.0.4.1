#pragma once

#include <string>

class LevelStorage
{
public:
	std::string getFullPath()const;
};
