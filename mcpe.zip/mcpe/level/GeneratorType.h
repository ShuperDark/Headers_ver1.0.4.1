#pragma once

enum class GeneratorType : int
{
	OLD,
	NORMAL,
	FLAT
};
