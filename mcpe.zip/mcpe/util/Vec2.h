#pragma once

class Vec2
{
public:
	float x;	// 0
	float y;	// 4
public:
	Vec2(float x,float y):x(x),y(y){}
	Vec2()=default;
};
