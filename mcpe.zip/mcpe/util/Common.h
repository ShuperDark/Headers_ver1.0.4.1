#pragma once

#include <string>

class Common
{
public:
	static std::string getGameVersionStringNet(void);
	static std::string getGameVersionString(void); 
};
