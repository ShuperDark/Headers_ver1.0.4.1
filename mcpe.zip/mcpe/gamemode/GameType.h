#pragma once

enum GameType
{
	SURVIVAL,
	CREATIVE
};
