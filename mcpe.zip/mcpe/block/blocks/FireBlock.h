#pragma once

#include "mcpe/block/Block.h"

class FireBlock : public Block
{
public:
	void setFlammable(BlockID,int,int);
};
