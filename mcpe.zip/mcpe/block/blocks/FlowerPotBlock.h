#pragma once

class FlowerPotBlock
{
public:
	bool isSupportedBlock(Block const*, short) const;
};
