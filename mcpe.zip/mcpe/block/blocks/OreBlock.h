#pragma once

#include "mcpe/block/Block.h"

class OreBlock : public Block
{
public:
	OreBlock(std::string const&,int);
};
