#pragma once

enum class BlockProperty : unsigned char
{
	
};
